import tkinter as tk
from tkinter import ttk
from pyrep import PyRep
import numpy as np
import math, threading, time, random,sys
from pyrep.backend import sim
from pyrep.objects import ProximitySensor, Shape, VisionSensor, Dummy
from pyrep.objects.joint import Joint


print("Please Enter File name:\n")
SF = input()
SF = f"{SF}.ttt"

pr = PyRep()
pr.launch(SF, headless=False)
pr.start()


try:
    left_wheel = Joint('leftjointp')
    right_wheel = Joint('rightjointp')
except Exception as e:
    print(f"Error initializing joints: {e}")
    pr.stop()
    pr.shutdown()
    exit()

wheel_radius = 0.03
robot_width = 0.2 
speed = 0.5
gain_p = 0.5
gain_d = 0.5
stop_thread = False


try:
    ir_rear_left = ProximitySensor('ir_rear_left')
    ir_front_left = ProximitySensor('ir_front_left')
    ir_rear_right = ProximitySensor('ir_rear_right')
    ir_front_right = ProximitySensor('ir_front_right')
    sonar = ProximitySensor('Proximity_sensor')
    vision_sensor = VisionSensor('Vision_sensor')
except Exception as e:
    print(f"Error initializing sensors: {e}")
    pr.stop()
    pr.shutdown()
    exit()





robot_pose = Dummy('robot_pose')
target_dummy = Dummy('ref_point')


def updateRobotPose():
    position = robot_pose.get_position()
    orientation = robot_pose.get_orientation()
    print(f"ROBOT POSE: Position = {position}, Orientation = {orientation}")
    pose = [position[0], position[1], orientation[2]]
    return pose


def getTrajectoryPoint():
    position = target_dummy.get_position()
    print(f"REF POSE: Position = {position}")
    orientation = target_dummy.get_orientation()
    print(f"REF OR: Orientation = {orientation}")
    linear_vel, angular_vel = target_dummy.get_velocity()
    print(f"LinearVel: {linear_vel}, AngularVel: {angular_vel}")
    ptraj = [0, 0, 0]
    if orientation[2] > 0:
        ptraj = [position[0], position[1], orientation[2] - math.pi / 2]
    else:
        ptraj = [position[0], position[1], math.pi / 2 - orientation[2]]
    vtraj = [linear_vel[0], linear_vel[1], angular_vel[2]]
    return ptraj, vtraj


def calculate_control():
    robot_position = np.array(robot_pose.get_position())[:2]
    target_position = np.array(target_dummy.get_position())[:2]


    error_position = target_position - robot_position
    distance_error = np.linalg.norm(error_position)
    desired_angle = math.atan2(error_position[1], error_position[0])

    robot_orientation = robot_pose.get_orientation()[2]
    angle_error = desired_angle - robot_orientation


    angle_error = (angle_error + math.pi) % (2 * math.pi) - math.pi


    random_deviation = random.uniform(-math.pi / 6, math.pi / 6) 
    desired_angle += random_deviation 


    angle_error = desired_angle - robot_orientation


    angle_error = (angle_error + math.pi) % (2 * math.pi) - math.pi


    linear_velocity = gain_p * distance_error
    angular_velocity = gain_d * angle_error


    left_velocity = (linear_velocity - (angular_velocity * robot_width / 2)) / wheel_radius * speed
    right_velocity = (linear_velocity + (angular_velocity * robot_width / 2)) / wheel_radius * speed


    print(f"Robot Position: {robot_position}, Target Position: {target_position}")
    print(f"Distance Error: {distance_error}, Angle Error: {angle_error}")
    print(f"Left Wheel Velocity: {left_velocity}, Right Wheel Velocity: {right_velocity}")
    
    return left_velocity, right_velocity
path = sim.simGetObjectHandle('Path')
ref_point=sim.simGetObjectHandle('ref_point')


def get_path_points(path_handle, num_points=10):
    points = []
    for i in range(num_points + 1):
        relative_distance = i / num_points 
        position = sim.simGetPositionOnPath(path_handle, relative_distance)
        points.append(position)
    return points
    
def update_target_position(current_target, path_points, threshold=0.05):

    robot_position = np.array(robot_pose.get_position())[:2]
    target_position = np.array(path_points[current_target])[:2]


    if np.linalg.norm(robot_position - target_position) < threshold:
        current_target += 1 
        if current_target >= len(path_points):
            current_target = 0  
        print(f"Target moved to point {current_target}: {path_points[current_target]}")
        target_dummy.set_position(path_points[current_target])

    return current_target

path_points = get_path_points(path)
current_target = 0
target_dummy.set_position(path_points[current_target])

vref= 0.1

def update_robot():
    global current_target
    while not stop_thread:
        left_velocity, right_velocity = calculate_control()


        left_wheel.set_joint_target_velocity(left_velocity)
        right_wheel.set_joint_target_velocity(right_velocity)


        current_target = update_target_position(current_target, path_points)


        print(f"Robot Moving: Left Wheel Velocity = {left_velocity}, Right Wheel Velocity = {right_velocity}")

        pr.step()
        time.sleep(0.1)  


def stop():
    left_wheel.set_joint_target_velocity(0)
    right_wheel.set_joint_target_velocity(0)
    global stop_thread
    stop_thread = True
    print("Robot Movement Stopped")
    pr.step()


def start_movement():
    global stop_thread
    stop_thread = False
    print("Robot Movement Started")
    message_label.config(text=f"Robot Moving to Target!")
    threading.Thread(target=update_robot, daemon=True).start()


root = tk.Tk()
root.title("DYRO Bot")
root.geometry("300x300")


start_button = tk.Button(root, text="Start Movement", command=start_movement)
start_button.pack(pady=10)

stop_button = tk.Button(root, text="Stop", command=stop)
stop_button.pack(pady=10)


message_label = tk.Label(root, text="")
message_label.pack(pady=10)


root.mainloop()


pr.stop()
pr.shutdown()

